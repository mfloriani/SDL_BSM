#pragma once


//int LoadTiledWalls(lua_State* state)
//{
//	int args = lua_gettop(state);
//
//	for (int i = 1; i <= args; ++i)
//	{
//		std::cout << lua_tostring(state, i) << std::endl;
//	}
//	return 1;
//}