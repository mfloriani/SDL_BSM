#pragma once
const double   PI = 3.14159;
const double   TWO_PI = PI * 2;
const double   HALF_PI = PI / 2;
const double   QUARTER_PI = PI / 4;