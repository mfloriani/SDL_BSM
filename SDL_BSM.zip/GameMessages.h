#pragma once

enum MessageType{
	Msg_Blank,
	Msg_Attack,
	Msg_Patrol,
	Msg_Chase,
	Msg_Die,
	Msg_BulletHit,
	Msg_ChaseEnded,
	Msg_PlayerSpotted,
	Msg_TargetLost,
	Msg_PatrolEnded
};
