#pragma once

enum
{
	invalid_node_index = -1
};