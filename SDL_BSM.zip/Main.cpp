#include "SDLGame.h"
#include "LuaTiledImporter.h"

int main(int argc, char* args[])
{	
	return Game->Run();
}
